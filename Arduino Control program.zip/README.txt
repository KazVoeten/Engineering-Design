README 4WBB0 CONTROLLER
-----------------------
Bart Verhaegh for TU/e 4WBB0 subject
b.j.verhaegh@student.tue.nl
15-09-2015
-----------------------

This controller can be used to send and receive information from/to the Arduino used in the TU/e 4WBB0 subject. Furthermore, the video uplink provided by the WiFi Unit provided to 4WBB0 participants can be viewed. The executable works on all current Windows versions. (XP/7/8/10)

A. HOW TO USE

Usage of the 
4WBB0 controller is quite straightforward:
- Make sure the computer and the WiFi Unit are both on the same network, either via an Ethernet cable or the 'search-rescue' wifi network.

- Make sure the WiFi unit is turned on and done booting (takes about 40sec)

- Enter the configured IP address in the input box

- Press 'connect'. You should now be able to view the camera uplink

- In the 'Controls' section, you should be able to send characters to the Arduino

- Feedback sent by the Arduino can be viewed in the 'Log' section